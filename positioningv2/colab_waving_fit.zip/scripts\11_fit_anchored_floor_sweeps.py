#!/usr/bin/env python3
"""Fit Lighthouse geometry from known floor anchor points."""

from __future__ import annotations

import argparse
import math

import numpy as np
import pandas as pd
from scipy.optimize import least_squares

from dynamic_lh2_common import (
    angle_residual,
    load_json,
    load_sensors_layout,
    pose_look_at,
    predict_angles,
    residual_quality,
    save_json,
    sensor_world_position,
)


TAN_30 = math.tan(math.radians(30.0))


def load_anchored_sweeps(path, sweep_source):
    df = pd.read_csv(path)
    sweep_columns = ("sweep0_deg", "sweep1_deg")
    if sweep_source == "model":
        sweep_columns = ("model_sweep0_deg", "model_sweep1_deg")
    required = [
        "point_id",
        "point_x",
        "point_y",
        "point_z",
        "point_yaw_deg",
        "sensor_id",
        "lighthouse_id",
        sweep_columns[0],
        sweep_columns[1],
    ]
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Missing anchored CSV columns: {missing}")
    df = df.dropna(subset=list(sweep_columns)).copy()
    df = df[df[sweep_columns[0]].astype(str) != ""]
    df = df[df[sweep_columns[1]].astype(str) != ""]
    for col in ("point_x", "point_y", "point_z", "point_yaw_deg", sweep_columns[0], sweep_columns[1]):
        df[col] = df[col].astype(float)
    df["sensor_id"] = df["sensor_id"].astype(int)
    df["lighthouse_id"] = df["lighthouse_id"].astype(int)
    df["measure_sweep0_deg"] = df[sweep_columns[0]]
    df["measure_sweep1_deg"] = df[sweep_columns[1]]
    return df.reset_index(drop=True), sweep_columns


def predict_sweeps(sensor_position_world, lighthouse_translation, lighthouse_rotvec):
    azimuth, elevation = predict_angles(sensor_position_world, lighthouse_translation, lighthouse_rotvec)
    return np.array([
        azimuth + TAN_30 * elevation,
        azimuth - TAN_30 * elevation,
    ], dtype=float)


def pack_initial(lighthouse_ids, settings):
    z_guess = float(settings.get("lighthouse_z_guess", 1.5))
    guesses = {
        lighthouse_ids[0]: np.array([1.2, 1.5, z_guess], dtype=float),
    }
    if len(lighthouse_ids) > 1:
        guesses[lighthouse_ids[1]] = np.array([-1.2, 1.5, z_guess], dtype=float)
    values = []
    lower = []
    upper = []
    for lh_id in lighthouse_ids:
        t = guesses.get(lh_id, np.array([0.0, 1.5, z_guess], dtype=float))
        r = pose_look_at(t, target=(0.0, 0.0, float(settings.get("drone_z", 0.0))))
        values.extend(t.tolist())
        values.extend(r.tolist())
        lower.extend([-8.0, -8.0, 0.2, -2.0 * math.pi, -2.0 * math.pi, -2.0 * math.pi])
        upper.extend([+8.0, +8.0, 4.0, +2.0 * math.pi, +2.0 * math.pi, +2.0 * math.pi])
    return np.asarray(values), (np.asarray(lower), np.asarray(upper))


def unpack(params, lighthouse_ids):
    offset = 0
    lighthouses = {}
    for lh_id in lighthouse_ids:
        lighthouses[lh_id] = {
            "translation": params[offset:offset + 3],
            "rotation_vector": params[offset + 3:offset + 6],
        }
        offset += 6
    return lighthouses


def residuals(params, lighthouse_ids, df, sensors):
    lighthouses = unpack(params, lighthouse_ids)
    out = []
    for row in df.itertuples(index=False):
        sensor_body = sensors.get(int(row.sensor_id))
        lighthouse = lighthouses.get(int(row.lighthouse_id))
        if sensor_body is None or lighthouse is None:
            continue
        pose = np.array([float(row.point_x), float(row.point_y), math.radians(float(row.point_yaw_deg))])
        p_world = sensor_world_position(pose, sensor_body, float(row.point_z))
        predicted = predict_sweeps(
            p_world,
            lighthouse["translation"],
            lighthouse["rotation_vector"],
        )
        measured = np.radians([float(row.measure_sweep0_deg), float(row.measure_sweep1_deg)])
        out.extend(angle_residual(measured, predicted).tolist())
    return np.asarray(out, dtype=float)


def point_errors(params, lighthouse_ids, df, sensors):
    lighthouses = unpack(params, lighthouse_ids)
    errors = []
    for row in df.itertuples(index=False):
        sensor_body = sensors.get(int(row.sensor_id))
        lighthouse = lighthouses.get(int(row.lighthouse_id))
        if sensor_body is None or lighthouse is None:
            continue
        pose = np.array([float(row.point_x), float(row.point_y), math.radians(float(row.point_yaw_deg))])
        p_world = sensor_world_position(pose, sensor_body, float(row.point_z))
        predicted = predict_sweeps(p_world, lighthouse["translation"], lighthouse["rotation_vector"])
        measured = np.radians([float(row.measure_sweep0_deg), float(row.measure_sweep1_deg)])
        err = np.degrees(np.max(np.abs(angle_residual(measured, predicted))))
        errors.append((row.point_id, int(row.sensor_id), int(row.lighthouse_id), float(err)))
    return errors


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--layout", default="config/sensors_layout.json")
    parser.add_argument("--settings", default="config/calibration_settings.json")
    parser.add_argument("--input", default="data/captures/anchored_floor9_sweeps.csv")
    parser.add_argument("--output", default="config/lighthouse_geometry_anchored_floor.json")
    parser.add_argument("--sweep-source", choices=["ordered", "model"], default="model")
    parser.add_argument("--max-nfev", type=int, default=2000)
    parser.add_argument("--reject-outliers-deg", type=float, default=None)
    parser.add_argument("--reject-rounds", type=int, default=1)
    args = parser.parse_args()

    _, sensors = load_sensors_layout(args.layout)
    settings = load_json(args.settings)
    df, sweep_columns = load_anchored_sweeps(args.input, args.sweep_source)
    expected = {int(x) for x in settings.get("expected_lighthouses", [4, 10])}
    df = df[df["lighthouse_id"].isin(expected)].copy()
    lighthouse_ids = sorted(int(x) for x in df["lighthouse_id"].unique())
    if len(lighthouse_ids) < 2:
        raise ValueError("Need observations from at least two lighthouses.")

    x0, bounds = pack_initial(lighthouse_ids, settings)
    f_scale = math.radians(float(settings.get("max_angle_error_deg", 5.0)))

    result = least_squares(
        residuals,
        x0,
        bounds=bounds,
        args=(lighthouse_ids, df, sensors),
        loss=settings.get("robust_loss", "soft_l1"),
        f_scale=f_scale,
        max_nfev=args.max_nfev,
    )

    removed_total = 0
    if args.reject_outliers_deg is not None:
        rounds = max(1, int(args.reject_rounds))
        for round_index in range(rounds):
            errs = point_errors(result.x, lighthouse_ids, df, sensors)
            bad = {(p, s, b) for p, s, b, e in errs if e > args.reject_outliers_deg}
            if not bad:
                break
            before = len(df)
            df = df[
                ~df.apply(lambda row: (row["point_id"], int(row["sensor_id"]), int(row["lighthouse_id"])) in bad, axis=1)
            ].copy()
            removed = before - len(df)
            removed_total += removed
            print(f"Removed outlier anchored observations round {round_index + 1}: {removed}")
            if len(df) < 4:
                raise ValueError("Too few observations left after outlier rejection.")
            result = least_squares(
                residuals,
                result.x,
                bounds=bounds,
                args=(lighthouse_ids, df, sensors),
                loss=settings.get("robust_loss", "soft_l1"),
                f_scale=f_scale,
                max_nfev=args.max_nfev,
            )

    res = residuals(result.x, lighthouse_ids, df, sensors)
    lighthouses = unpack(result.x, lighthouse_ids)
    quality = residual_quality(res)
    quality.update({
        "num_observations": int(len(df)),
        "num_points": int(df["point_id"].nunique()),
        "sweep_source": args.sweep_source,
        "sweep_columns": list(sweep_columns),
        "outliers_removed": int(removed_total),
    })

    output = {
        "version": 1,
        "model": "anchored_floor_sweep_approximation",
        "units": "meters",
        "angle_units": "radians",
        "drone_z_assumed": float(settings.get("drone_z", 0.0)),
        "anchors": {
            "yaw_fixed_deg": 0.0,
            "note": "Drone anchor point x/y/yaw are fixed by floor marks.",
        },
        "lighthouses": [
            {
                "id": int(lh_id),
                "translation": lighthouses[lh_id]["translation"].tolist(),
                "rotation_vector": lighthouses[lh_id]["rotation_vector"].tolist(),
            }
            for lh_id in sorted(lighthouses)
        ],
        "calibration_quality": quality,
    }
    save_json(args.output, output)

    print("=" * 70)
    print("Fit anchored floor Lighthouse geometry")
    print(f"Input: {args.input}")
    print(f"Sweep source: {args.sweep_source} columns={sweep_columns[0]},{sweep_columns[1]}")
    print(f"points={quality['num_points']} observations={quality['num_observations']}")
    print(f"Success: {result.success} | cost={result.cost:.6g} | nfev={result.nfev}")
    for item in output["lighthouses"]:
        t = item["translation"]
        r = item["rotation_vector"]
        print(
            f"BS{item['id']}: "
            f"translation=({t[0]:+.3f},{t[1]:+.3f},{t[2]:+.3f}) m "
            f"rotvec=({r[0]:+.3f},{r[1]:+.3f},{r[2]:+.3f})"
        )
    print(
        f"RMSE={quality['rmse_deg']:.3f} deg | "
        f"median={quality['median_error_deg']:.3f} deg | "
        f"max={quality['max_error_deg']:.3f} deg"
    )
    print(f"Saved: {args.output}")
    print("=" * 70)


if __name__ == "__main__":
    main()
